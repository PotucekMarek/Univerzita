<?php
session_start();
include '../dbconnection.php';
include '../models/UserModel.php';
include '../models/LoginModel.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../views/login.php");
    exit();
}

$userModel = new UserModel($conn);
$loginModel = new LoginModel($conn);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_user'])) {
        $id = htmlspecialchars($_POST['id']);
        $name = htmlspecialchars($_POST['name']);
        $lastName = htmlspecialchars($_POST['lastName']);
        $email = htmlspecialchars($_POST['email']);
        $phoneNumber = htmlspecialchars($_POST['phoneNumber']);
        $workRoom = htmlspecialchars($_POST['workRoom']);
        $userModel->updateUser($id, $name, $lastName, $email, $phoneNumber, $workRoom);
    } elseif (isset($_POST['change_password'])) {
        $id = htmlspecialchars($_POST['id']);
        $newPassword = htmlspecialchars($_POST['newPassword']);
        $confirmPassword = htmlspecialchars($_POST['confirmPassword']);
        if ($newPassword === $confirmPassword) {
            $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
            $loginModel->changePassword($id, $hashedPassword);
        } else {
            $passwordError = "Passwords do not match!";
        }
    } elseif (isset($_POST['delete'])) {
        $idToDelete = $_POST['delete'];
        $userModel->deleteUser($idToDelete);
        $loginModel->deleteUserLogin($idToDelete);
    }
    header("Location: ../views/users.php");
    exit();
}

$users = $userModel->getAllUsers();
include '../views/users.php';
?>