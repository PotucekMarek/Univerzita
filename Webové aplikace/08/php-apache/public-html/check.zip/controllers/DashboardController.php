<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include dirname(__DIR__) . '/dbconnection.php';
include dirname(__DIR__) . '/models/UserModel.php';

$userModel = new UserModel($conn);
$recentUsers = $userModel->getRecentUsers(10);

include dirname(__DIR__) . '/views/dashboard.php';