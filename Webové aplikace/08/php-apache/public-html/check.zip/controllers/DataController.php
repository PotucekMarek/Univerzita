<?php
session_start();
include '../dbconnection.php';
include '../models/UserModel.php';
include '../models/LoginModel.php';

if (!isset($_SESSION['username'])) {
    header("Location: ../views/login.php");
    exit();
}

$isAdmin = isset($_SESSION['role']) && $_SESSION['role'] == 'admin';
$userModel = new UserModel($conn);
$loginModel = new LoginModel($conn);

$username = $_SESSION['username'];
$user = $userModel->getUserByUsername($username);

$showEditModal = false;
$showPasswordModal = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_user'])) {
        $id = htmlspecialchars($_POST['id']);
        $name = htmlspecialchars($_POST['name']);
        $lastName = htmlspecialchars($_POST['lastName']);
        $email = htmlspecialchars($_POST['email']);
        $phoneNumber = htmlspecialchars($_POST['phoneNumber']);
        $workRoom = htmlspecialchars($_POST['workRoom']);
        if ($id) {
            $userModel->updateUser($id, $name, $lastName, $email, $phoneNumber, $workRoom);
        } else {
            $userModel->insertUser($name, $lastName, $email, $phoneNumber, $workRoom);
        }
        $_SESSION['username'] = $name;
        header("Location: ../views/data.php");
        exit();
    } elseif (isset($_POST['change_password'])) {
        $id = htmlspecialchars($_POST['id']);
        $newPassword = htmlspecialchars($_POST['newPassword']);
        $confirmPassword = htmlspecialchars($_POST['confirmPassword']);
        if ($newPassword === $confirmPassword) {
            $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
            $loginModel->changePassword($id, $hashedPassword);
            header("Location: ../views/data.php");
            exit();
        } else {
            $passwordError = "Passwords do not match!";
            $showPasswordModal = true;
        }
    } elseif (isset($_POST['edit_user'])) {
        $showEditModal = true;
    } elseif (isset($_POST['show_change_password'])) {
        $showPasswordModal = true;
    }
}

include '../views/data.php';
?>