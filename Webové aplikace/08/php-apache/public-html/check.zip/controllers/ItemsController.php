<?php
session_start();
include '../dbconnection.php';
include '../models/UserModel.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../views/dashboard.php");
    exit();
}

$userModel = new UserModel($conn);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_item'])) {
    $name = htmlspecialchars($_POST['name']);
    $lastName = htmlspecialchars($_POST['lastName']);
    $email = htmlspecialchars($_POST['email']);
    $phoneNumber = htmlspecialchars($_POST['phoneNumber']);
    $workRoom = htmlspecialchars($_POST['workRoom']);
    $userModel->insertUser($name, $lastName, $email, $phoneNumber, $workRoom);

    header("Location: ../views/items.php");
    exit();
}

include '../views/items.php';
?>