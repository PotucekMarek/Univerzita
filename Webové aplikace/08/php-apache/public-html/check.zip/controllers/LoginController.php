<?php
session_start();
include '../dbconnection.php';
include '../models/LoginModel.php';

$loginModel = new LoginModel($conn);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars($_POST['password']);
    $user = $loginModel->getUserByUsername($username);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $user['role'];
        header("Location: ../views/dashboard.php");
        exit();
    } else {
        $msg = "Please check your inputs!";
    }
}

include '../views/login.php';
?>