<?php
class UserModel {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function getRecentUsers($limit) {
        $sql = "SELECT id, username FROM login_table ORDER BY id DESC LIMIT ?";
        if ($stmt = $this->conn->prepare($sql)) {
            $stmt->bind_param("i", $limit);
            $stmt->execute();
            $result = $stmt->get_result();
            $users = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            return $users;
        }
        return [];
    }

    public function getUserByUsername($username) {
        $sql = "SELECT * FROM user_table WHERE name=?";
        if ($stmt = $this->conn->prepare($sql)) {
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close();
            return $user;
        }
        return null;
    }

    public function getAllUsers() {
        $sql = "SELECT * FROM user_table";
        $result = $this->conn->query($sql);
        $users = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
            $result->free();
        }
        return $users;
    }

    public function updateUser($id, $name, $lastName, $email, $phoneNumber, $workRoom) {
        $sql = "UPDATE user_table SET name=?, lastName=?, email=?, phoneNumber=?, workRoom=? WHERE id=?";
        if ($stmt = $this->conn->prepare($sql)) {
            $stmt->bind_param("sssssi", $name, $lastName, $email, $phoneNumber, $workRoom, $id);
            return $stmt->execute();
        }
        return false;
    }

    public function insertUser($name, $lastName, $email, $phoneNumber, $workRoom) {
        $sql = "INSERT INTO user_table (name, lastName, email, phoneNumber, workRoom) VALUES (?, ?, ?, ?, ?)";
        if ($stmt = $this->conn->prepare($sql)) {
            $stmt->bind_param("sssss", $name, $lastName, $email, $phoneNumber, $workRoom);
            return $stmt->execute();
        }
        return false;
    }

    public function deleteUser($id) {
        $sql = "DELETE FROM user_table WHERE id = ?";
        if ($stmt = $this->conn->prepare($sql)) {
            $stmt->bind_param("i", $id);
            return $stmt->execute();
        }
        return false;
    }
}
?>