<?php

include 'dbconnection.php';

// Simple router to handle requests
$request = str_replace("/05/php-apache/public-html", "", $_SERVER['REQUEST_URI']); // Adjust this part

switch ($request) {
    case '/' :
    case '/dashboard':
        require __DIR__ . '/controllers/DashboardController.php';
        break;
    case '/users' :
        require __DIR__ . '/controllers/UsersController.php';
        break;
    case '/items' :
        require __DIR__ . '/controllers/ItemsController.php';
        break;
    case '/login' :
        require __DIR__ . '/controllers/LoginController.php';
        break;
    case '/data' :
        require __DIR__ . '/controllers/DataController.php';
        break;
    default:
        http_response_code(404);
        echo "404 Not Found";
        break;
}
?>